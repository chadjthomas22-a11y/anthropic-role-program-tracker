import { useState, useEffect } from "react";

const INITIAL_DATA = [
  {
    id: "r1",
    title: "Certified Partner Program Design",
    shortTitle: "Partner Program",
    desc: "Drive the Anthropic Certified Partner Program \u2014 defining tiers, certification criteria, enablement curriculum, co-activation frameworks, and performance accountability standards that extend Anthropic\u2019s existing partner infrastructure into an activation-ready ecosystem.",
    status: "not_started",
    targetDate: "2026-07-15",
    priority: "critical",
    startHere: true,
    recommendation: "Start here. Map existing partner tiers and certification criteria. Audit the CCA Foundations program adoption data. Interview 5 anchor partners (Accenture, Deloitte, Cognizant) on what\u2019s working and what\u2019s missing in their activation journey. Deliver a v1 tier framework by day 30.",
    kpis: [
      { label: "Partner tiers defined", target: 4, current: 0, unit: "tiers" },
      { label: "Certification completion rate", target: 70, current: 0, unit: "%" },
      { label: "Partners meeting tier criteria", target: 50, current: 0, unit: "partners" },
      { label: "Enablement curriculum modules", target: 12, current: 0, unit: "modules" },
    ],
  },
  {
    id: "r2",
    title: "High-Leverage Partner Recruitment",
    shortTitle: "Partner Recruitment",
    desc: "Identify, recruit, and onboard the highest-leverage partners (SIs, consulting firms, MSPs, technology partners) for driving Tier C account AI adoption at scale \u2014 with a prioritized view of where ROI is highest fastest.",
    status: "not_started",
    targetDate: "2026-08-01",
    priority: "high",
    startHere: false,
    recommendation: "Build a partner scoring model (technical depth, deal pipeline, industry coverage, geographic reach). Start with the 10 highest-ROI partners outside the anchor group. Use the BetterUp dashboard playbook as a template for tracking recruitment pipeline.",
    kpis: [
      { label: "Partners in pipeline", target: 50, current: 0, unit: "partners" },
      { label: "Partners onboarded", target: 25, current: 0, unit: "partners" },
      { label: "Time to first deployment", target: 45, current: 0, unit: "days avg" },
      { label: "Partner-sourced pipeline value", target: 10, current: 0, unit: "$M" },
    ],
  },
  {
    id: "r3",
    title: "Partner Enablement Toolkit",
    shortTitle: "Enablement Toolkit",
    desc: "Co-develop the partner enablement toolkit with Product and Growth Marketing capability leads: training content, activation playbooks, co-sell materials, and technical resources that allow certified partners to run Anthropic\u2019s activation motion independently and consistently.",
    status: "not_started",
    targetDate: "2026-08-15",
    priority: "critical",
    startHere: false,
    recommendation: "Audit existing Partner Portal assets. Gap-analyze against what partners actually need in the field. Build vertical-specific playbooks for the top 3 use cases: code modernization (Claude Code starter kit), customer support automation (API + MCP), and knowledge management (Enterprise + MCP connectors).",
    kpis: [
      { label: "Playbooks published", target: 8, current: 0, unit: "playbooks" },
      { label: "Partner NPS on enablement", target: 60, current: 0, unit: "NPS" },
      { label: "Toolkit adoption rate", target: 80, current: 0, unit: "%" },
      { label: "Co-sell materials created", target: 15, current: 0, unit: "assets" },
    ],
  },
  {
    id: "r4",
    title: "Partner Feedback Loop",
    shortTitle: "Feedback Loop",
    desc: "Design the partner feedback loop \u2014 mechanisms for capturing what works in partner-led activations, codifying learnings into updated playbooks, and surfacing insights back to the programmatic team.",
    status: "not_started",
    targetDate: "2026-09-01",
    priority: "high",
    startHere: false,
    recommendation: "Stand up a lightweight feedback mechanism in week 1 (even a structured form). Formalize into a quarterly partner insights report by month 3. Connect to the Claude Control Tower telemetry once Systems/Process capability lead is aligned. First insights brief to leadership by day 90.",
    kpis: [
      { label: "Partner feedback submissions", target: 100, current: 0, unit: "/quarter" },
      { label: "Insights surfaced to Product", target: 20, current: 0, unit: "/quarter" },
      { label: "Playbook updates from field data", target: 6, current: 0, unit: "/quarter" },
      { label: "Feedback loop cycle time", target: 14, current: 0, unit: "days" },
    ],
  },
  {
    id: "r5",
    title: "Partner Tooling & Infrastructure",
    shortTitle: "Tooling & Infra",
    desc: "Collaborate with Product and Systems/Process capability leads to ensure partners have access to the right tools, telemetry, and infrastructure to manage their Tier C portfolio.",
    status: "not_started",
    targetDate: "2026-09-15",
    priority: "medium",
    startHere: false,
    recommendation: "Map the current partner tech stack (Portal, Skilljar, CRM). Identify gaps in telemetry \u2014 what usage signals do partners need to see for their accounts? Co-design the partner view of the Claude Control Tower with the Systems capability lead. Prioritize signals: seat activation, daily active usage, MCP connector adoption.",
    kpis: [
      { label: "Partner portal daily active users", target: 200, current: 0, unit: "DAU" },
      { label: "Telemetry signals available", target: 15, current: 0, unit: "signals" },
      { label: "Tool satisfaction score", target: 4.2, current: 0, unit: "/5" },
      { label: "API integration partners", target: 10, current: 0, unit: "partners" },
    ],
  },
  {
    id: "r6",
    title: "Partner Performance Metrics",
    shortTitle: "Performance Metrics",
    desc: "Establish partner performance metrics in partnership with Strat Ops: activation rates, adoption outcomes, revenue contribution from partner-influenced accounts, and partner health scoring for the ecosystem.",
    status: "not_started",
    targetDate: "2026-08-01",
    priority: "critical",
    startHere: false,
    recommendation: "Define the partner health score formula in the first 30 days. Align with Strat Ops on data sources. Build a v1 partner dashboard (your BetterUp experience is directly transferable here). Present to leadership by day 60. Iterate based on what Alliances and Sales teams actually need to see.",
    kpis: [
      { label: "Partner activation rate", target: 75, current: 0, unit: "%" },
      { label: "Partner-influenced revenue", target: 30, current: 0, unit: "$M/quarter" },
      { label: "Adoption rate (partner-led)", target: 65, current: 0, unit: "%" },
      { label: "Partner health score coverage", target: 100, current: 0, unit: "%" },
    ],
  },
  {
    id: "r7",
    title: "Cross-Functional Alignment",
    shortTitle: "Cross-Functional",
    desc: "Hold the connective tissue across Alliances, Sales, Marketing, and the Partnerships org to align the partner activation program with Anthropic\u2019s broader partner strategy \u2014 this role is the integration point that reduces duplication and resolves channel conflict.",
    status: "not_started",
    targetDate: "2026-07-01",
    priority: "critical",
    startHere: true,
    recommendation: "Second priority after R1. Schedule 1:1s with every functional lead in weeks 1-2 (Steve Corfield, Phil Samenuk, Sales leads, Growth Marketing). Map the current RACI for partner-related activities. Identify the top 3 channel conflicts and propose resolution frameworks. Establish a bi-weekly partner ops sync.",
    kpis: [
      { label: "Channel conflicts resolved", target: 10, current: 0, unit: "/quarter" },
      { label: "Cross-functional sync attendance", target: 95, current: 0, unit: "%" },
      { label: "Duplication incidents", target: 2, current: 0, unit: "/qtr (lower=better)" },
      { label: "Internal stakeholder NPS", target: 55, current: 0, unit: "NPS" },
    ],
  },
  {
    id: "r8",
    title: "Internal Authority & Representation",
    shortTitle: "Internal Authority",
    desc: "Serve as the internal authority on partner-led activation; represent the programmatic outcomes perspective in partner strategy discussions.",
    status: "not_started",
    targetDate: "2026-10-01",
    priority: "medium",
    startHere: false,
    recommendation: "This is earned, not assigned. Build credibility through the first 90 days by delivering R1, R6, and R7. Present a partner ecosystem state-of-the-union to leadership at the 90-day mark. Publish a monthly partner activation insights brief. By Q3, you should be the person everyone turns to for partner activation decisions.",
    kpis: [
      { label: "Leadership presentations", target: 4, current: 0, unit: "/quarter" },
      { label: "Partner insights briefs", target: 3, current: 0, unit: "/quarter" },
      { label: "Strategy discussions included", target: 90, current: 0, unit: "%" },
      { label: "Exec sponsor alignment", target: 4.5, current: 0, unit: "/5" },
    ],
  },
];

const STATUS_OPTIONS = [
  { value: "not_started", label: "Not started", color: "#5F5E5A", bg: "#F1EFE8" },
  { value: "in_progress", label: "In progress", color: "#185FA5", bg: "#E6F1FB" },
  { value: "on_track", label: "On track", color: "#0F6E56", bg: "#E1F5EE" },
  { value: "at_risk", label: "At risk", color: "#BA7517", bg: "#FAEEDA" },
  { value: "blocked", label: "Blocked", color: "#A32D2D", bg: "#FCEBEB" },
  { value: "complete", label: "Complete", color: "#3B6D11", bg: "#EAF3DE" },
];

const PRIORITY_COLORS = {
  critical: { color: "#A32D2D", bg: "#FCEBEB", label: "Critical path" },
  high: { color: "#BA7517", bg: "#FAEEDA", label: "High" },
  medium: { color: "#185FA5", bg: "#E6F1FB", label: "Medium" },
};

export default function Dashboard() {
  const [data, setData] = useState(() => {
    try {
      const saved = localStorage.getItem("po_dashboard_v2");
      return saved ? JSON.parse(saved) : INITIAL_DATA;
    } catch { return INITIAL_DATA; }
  });
  const [selectedId, setSelectedId] = useState(null);
  const [view, setView] = useState("overview");

  useEffect(() => {
    try { localStorage.setItem("po_dashboard_v2", JSON.stringify(data)); } catch {}
  }, [data]);

  const updateItem = (id, updates) => {
    setData(prev => prev.map(d => d.id === id ? { ...d, ...updates } : d));
  };

  const updateKpi = (itemId, kpiIdx, value) => {
    setData(prev => prev.map(d => {
      if (d.id !== itemId) return d;
      const newKpis = [...d.kpis];
      newKpis[kpiIdx] = { ...newKpis[kpiIdx], current: parseFloat(value) || 0 };
      return { ...d, kpis: newKpis };
    }));
  };

  const completedCount = data.filter(d => d.status === "complete").length;
  const atRiskCount = data.filter(d => d.status === "at_risk" || d.status === "blocked").length;
  const inFlightCount = data.filter(d => d.status === "in_progress" || d.status === "on_track").length;
  const overallProgress = Math.round(data.reduce((sum, d) => {
    const kpiProgress = d.kpis.reduce((s, k) => s + Math.min(k.current / k.target, 1), 0) / d.kpis.length;
    return sum + kpiProgress;
  }, 0) / data.length * 100);

  const startHereItems = data.filter(d => d.startHere);

  const resetAll = () => {
    if (window.confirm("Reset all progress? This cannot be undone.")) {
      setData(INITIAL_DATA);
      setSelectedId(null);
    }
  };

  const styles = {
    container: { maxWidth: "100%", padding: 0 },
    header: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 8 },
    tag: { fontSize: 11, fontWeight: 700, letterSpacing: 1.5, color: "#D4763C", textTransform: "uppercase" },
    h1: { fontSize: 22, fontWeight: 700, color: "#1A1A2E", marginTop: 2 },
    rule: { height: 2, background: "#1A1A2E", marginBottom: 18 },
    statsGrid: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8, marginBottom: 20 },
    statBox: { background: "#F1EFE8", borderRadius: 8, padding: "14px 10px", textAlign: "center" },
    statNum: { fontSize: 22, fontWeight: 700 },
    statLabel: { fontSize: 10, color: "#888", marginTop: 2 },
    viewBar: { display: "flex", gap: 6, marginBottom: 18 },
    resetBtn: { fontSize: 11, padding: "4px 12px", background: "transparent", border: "1px solid #ddd", borderRadius: 6, cursor: "pointer", color: "#999", marginTop: 6 },
    card: (isOpen) => ({ border: `1px solid ${isOpen ? "#1A1A2E" : "#e0e0e0"}`, borderRadius: 10, marginBottom: 8, overflow: "hidden", transition: "border-color 0.15s" }),
    cardHeader: (isOpen) => ({ padding: "12px 16px", cursor: "pointer", display: "flex", alignItems: "center", gap: 10, background: isOpen ? "#F7F5F2" : "transparent" }),
    cardBody: { padding: "0 16px 16px", borderTop: "1px solid #eee" },
    pill: (bg, color) => ({ fontSize: 10, fontWeight: 600, padding: "2px 8px", borderRadius: 6, background: bg, color, whiteSpace: "nowrap" }),
    recBox: { background: "#FFFCF9", border: "1px solid #F0997B", borderRadius: 8, padding: 12, marginBottom: 14 },
    kpiGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 },
    kpiCard: { border: "1px solid #e8e8e8", borderRadius: 8, padding: "10px 12px" },
    kpiLabel: { fontSize: 10, color: "#888", marginBottom: 4 },
    kpiInput: { width: 56, fontSize: 15, fontWeight: 600, border: "1px solid #ddd", borderRadius: 4, padding: "3px 6px", textAlign: "center", fontFamily: "inherit" },
    bar: { height: 5, background: "#eee", borderRadius: 3, marginTop: 8, overflow: "hidden" },
    barFill: (pct) => ({ height: "100%", width: `${pct}%`, background: pct >= 80 ? "#1D9E75" : pct >= 40 ? "#185FA5" : "#B4B2A9", borderRadius: 3, transition: "width 0.3s" }),
    startCard: { border: "2px solid #D4763C", borderRadius: 10, padding: 18, marginBottom: 12, background: "#FFFCF9" },
    seqBox: { fontSize: 12, color: "#4A4A6A", marginTop: 16, padding: 14, background: "#F1EFE8", borderRadius: 8, lineHeight: 1.7 },
  };

  const ViewBtn = ({ v, label }) => (
    <button onClick={() => { setView(v); setSelectedId(null); }}
      style={{ fontSize: 12, padding: "6px 16px", background: view === v ? "#1A1A2E" : "transparent", color: view === v ? "#fff" : "#666", border: `1px solid ${view === v ? "#1A1A2E" : "#ccc"}`, borderRadius: 6, cursor: "pointer", fontWeight: view === v ? 600 : 400, fontFamily: "inherit" }}>
      {label}
    </button>
  );

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div>
          <div style={styles.tag}>Head of programmatic outcomes \u2014 Partners</div>
          <div style={styles.h1}>Responsibility tracker</div>
        </div>
        <button onClick={resetAll} style={styles.resetBtn}>Reset all</button>
      </div>
      <div style={styles.rule} />

      {/* Stats */}
      <div style={styles.statsGrid}>
        {[
          { n: `${overallProgress}%`, l: "Overall progress" },
          { n: `${completedCount}/${data.length}`, l: "Complete" },
          { n: String(atRiskCount), l: "At risk / blocked" },
          { n: String(inFlightCount), l: "In flight" },
        ].map((s, i) => (
          <div key={i} style={styles.statBox}>
            <div style={styles.statNum}>{s.n}</div>
            <div style={styles.statLabel}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* View toggle */}
      <div style={styles.viewBar}>
        <ViewBtn v="overview" label="All responsibilities" />
        <ViewBtn v="start" label="Where to start" />
        <ViewBtn v="kpis" label="KPI tracker" />
      </div>

      {/* WHERE TO START */}
      {view === "start" && (
        <div>
          <div style={{ fontSize: 13, color: "#4A4A6A", marginBottom: 14, lineHeight: 1.6 }}>
            These two responsibilities create the foundation everything else builds on. Tackle them first.
          </div>
          {startHereItems.map(item => (
            <div key={item.id} style={styles.startCard}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                <span style={styles.pill("#FAECE7", "#D4763C")}>Start here</span>
                <span style={{ fontSize: 15, fontWeight: 600 }}>{item.title}</span>
              </div>
              <div style={{ fontSize: 12, color: "#4A4A6A", lineHeight: 1.7, marginBottom: 10 }}>{item.recommendation}</div>
              <div style={{ fontSize: 11, color: "#888" }}>Target: {new Date(item.targetDate + "T00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</div>
            </div>
          ))}
          <div style={styles.seqBox}>
            <strong style={{ color: "#1A1A2E" }}>Recommended 90-day sequence:</strong><br />
            <strong>Weeks 1\u20132:</strong> Cross-functional 1:1s + partner ecosystem audit (R7, R1)<br />
            <strong>Weeks 3\u20136:</strong> Partner scoring model + health dashboard v1 (R6, R2)<br />
            <strong>Weeks 7\u201310:</strong> Enablement toolkit + vertical playbooks (R3, R5)<br />
            <strong>Weeks 11\u201312:</strong> Feedback loop + first partner insights brief (R4, R8)
          </div>
        </div>
      )}

      {/* KPI TRACKER */}
      {view === "kpis" && (
        <div>
          {data.map(item => (
            <div key={item.id} style={{ marginBottom: 18 }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8, display: "flex", alignItems: "center", gap: 8 }}>
                <span style={styles.pill(PRIORITY_COLORS[item.priority].bg, PRIORITY_COLORS[item.priority].color)}>
                  {PRIORITY_COLORS[item.priority].label}
                </span>
                {item.shortTitle}
              </div>
              <div style={styles.kpiGrid}>
                {item.kpis.map((kpi, ki) => {
                  const pct = Math.round(Math.min(kpi.current / kpi.target, 1) * 100);
                  return (
                    <div key={ki} style={styles.kpiCard}>
                      <div style={styles.kpiLabel}>{kpi.label}</div>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <input type="number" value={kpi.current}
                          onChange={e => updateKpi(item.id, ki, e.target.value)}
                          style={styles.kpiInput} />
                        <span style={{ fontSize: 11, color: "#888" }}>/ {kpi.target} {kpi.unit}</span>
                      </div>
                      <div style={styles.bar}><div style={styles.barFill(pct)} /></div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* OVERVIEW */}
      {view === "overview" && (
        <div>
          {data.map(item => {
            const isOpen = selectedId === item.id;
            const statusInfo = STATUS_OPTIONS.find(s => s.value === item.status);
            const kpiProgress = Math.round(item.kpis.reduce((s, k) => s + Math.min(k.current / k.target, 1), 0) / item.kpis.length * 100);
            return (
              <div key={item.id} style={styles.card(isOpen)}>
                <div onClick={() => setSelectedId(isOpen ? null : item.id)} style={styles.cardHeader(isOpen)}>
                  <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                    {item.startHere && <span style={styles.pill("#FAECE7", "#D4763C")}>START</span>}
                    <span style={styles.pill(PRIORITY_COLORS[item.priority].bg, PRIORITY_COLORS[item.priority].color)}>
                      {PRIORITY_COLORS[item.priority].label}
                    </span>
                    <span style={{ fontSize: 13, fontWeight: 600 }}>{item.title}</span>
                  </div>
                  <span style={styles.pill(statusInfo.bg, statusInfo.color)}>{statusInfo.label}</span>
                  <span style={{ fontSize: 11, color: "#888", minWidth: 36, textAlign: "right" }}>{kpiProgress}%</span>
                  <span style={{ fontSize: 14, color: "#bbb", transform: isOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s", lineHeight: 1 }}>{"\u25BE"}</span>
                </div>

                {isOpen && (
                  <div style={styles.cardBody}>
                    <div style={{ fontSize: 12, color: "#4A4A6A", lineHeight: 1.7, margin: "12px 0" }}>{item.desc}</div>

                    <div style={{ display: "flex", flexWrap: "wrap", gap: 12, marginBottom: 14, alignItems: "flex-end" }}>
                      <div>
                        <div style={{ fontSize: 10, color: "#888", marginBottom: 3 }}>Status</div>
                        <select value={item.status} onChange={e => updateItem(item.id, { status: e.target.value })}
                          style={{ fontSize: 12, padding: "5px 10px", borderRadius: 6, border: "1px solid #ccc", fontFamily: "inherit" }}>
                          {STATUS_OPTIONS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                        </select>
                      </div>
                      <div>
                        <div style={{ fontSize: 10, color: "#888", marginBottom: 3 }}>Target date</div>
                        <input type="date" value={item.targetDate} onChange={e => updateItem(item.id, { targetDate: e.target.value })}
                          style={{ fontSize: 12, padding: "5px 10px", borderRadius: 6, border: "1px solid #ccc", fontFamily: "inherit" }} />
                      </div>
                    </div>

                    <div style={styles.recBox}>
                      <div style={{ fontSize: 10, fontWeight: 700, color: "#D4763C", marginBottom: 4, textTransform: "uppercase", letterSpacing: 1 }}>Recommendation</div>
                      <div style={{ fontSize: 12, color: "#4A4A6A", lineHeight: 1.7 }}>{item.recommendation}</div>
                    </div>

                    <div style={{ fontSize: 10, fontWeight: 700, color: "#888", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 }}>Key performance indicators</div>
                    <div style={styles.kpiGrid}>
                      {item.kpis.map((kpi, ki) => {
                        const pct = Math.round(Math.min(kpi.current / kpi.target, 1) * 100);
                        return (
                          <div key={ki} style={styles.kpiCard}>
                            <div style={styles.kpiLabel}>{kpi.label}</div>
                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                              <input type="number" value={kpi.current}
                                onChange={e => updateKpi(item.id, ki, e.target.value)}
                                style={styles.kpiInput} />
                              <span style={{ fontSize: 11, color: "#888" }}>/ {kpi.target} {kpi.unit}</span>
                            </div>
                            <div style={styles.bar}><div style={styles.barFill(pct)} /></div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <div style={{ marginTop: 24, paddingTop: 12, borderTop: "1px solid #e0e0e0", fontSize: 10, color: "#bbb", display: "flex", justifyContent: "space-between" }}>
        <span>Chad J. Thomas | Anthropic Role Tracker</span>
        <span>April 2026</span>
      </div>
    </div>
  );
}
